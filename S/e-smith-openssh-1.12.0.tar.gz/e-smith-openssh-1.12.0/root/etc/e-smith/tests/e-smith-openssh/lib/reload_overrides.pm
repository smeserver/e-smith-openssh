# Welcome to the Wonderful World of Glassbox Testing.
#
# Load up esmith::util/system and override them with testing stubs.

use Test::More 'no_plan';

# Here we tell the test to not use any numbers (because there were
# probably tests output'd before us) and to not do end-of-test
# checks.
my $TB = Test::More->builder;
$TB->use_numbers(0);
$TB->no_ending(1);

use esmith::util;
use esmith::util::system;


package esmith::util;

::can_ok('esmith::util', 'serviceControl');

no warnings 'redefine';
sub serviceControl {
    my(%params) = @_;

    ::pass('service control called');
    ::is( $params{NAME},   'sshd', 'serviceControl NAME   == sshd' );
    ::is( $params{ACTION}, 'stop', '               ACTION == stop' );

    return 1;
}


package esmith::util::system;

::can_ok('esmith::util::system', 'killall');

no warnings 'redefine';
sub killall {
    my($sig, @commands) = @_;

    ::pass('killall called');
    ::is( $sig, 'HUP',          '       with a HUP' );
    ::is( @commands,    1,      '       one command' );
    ::is( $commands[0], 'sshd', '       for sshd' );

    return 1;
}
